﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ReedSolomon
{
    class Program
    {
        static void Main(string[] args)
        {
          // Encoding u8 = Encoding.UTF8;
          ////  Encoding u8 = Encoding.ASCII;
          //  string a = "HELLO WORD";
          //  int iBC = u8.GetByteCount(a);
          //  byte[] bytesa = u8.GetBytes(a);
          //  string b = "HELLO WORF";
          //  byte[] bytesb = u8.GetBytes(b);
          //  byte[] result = ReedSolomonAlgorithm.Encode(bytesa, 7);
         //   byte[] result1 = { 2, 32, 103, 49, 210, 205, 24 };
            //byte[] result1 = ReedSolomonAlgorithm.Decode(bytesb, result);
            //foreach (byte val in a) Console.Write(val + " ");
            //Console.WriteLine();
            //foreach (byte val in result) Console.Write(val + " ");
            //Console.WriteLine();
            //foreach (byte val in b) Console.Write(val + " ");
            //Console.WriteLine();
            //foreach (byte val in result1) Console.Write(val + " ");

            // Exemple à partir des 8 bits suivants, on veut créer un octet 01101111
            //byte result = 0b_0000_0000;

            //byte[] bytes = { 0b_0000_0001 , 0b_0000_0000, 0b_0000_0001, 0b_0000_0000, 0b_0000_0001,
            //    0b_0000_0000,0b_0000_0001 , 0b_0000_0000 };
            //byte mask = 0b_0000_0001;
            //int i = bytes.Length - 1;
            //while (mask != 0)
            //{
            //    if (bytes[i] != 0)
            //        result += (byte)Math.Pow((double)2, (double)(bytes.Length - i - 1));
            //    mask = (byte)((int)mask << 1);
            //    Console.WriteLine(Convert.ToString(result, toBase: 2));
            //    i--;
            //}
            //Console.WriteLine(result);
            //int val = 11;
            //byte result = 0b_0000_0000;
            //byte[] result1 = new byte[4];
            //int i = result1.Length-1;

            //while (val >= 2)
            //{
            //    result1[i] = (byte) (val % 2);
            //    val /= 2;
            //    i--;

            //}
            //result1[i] = (byte)val;
            //byte mask = 0b_0000_0001;
            //i = result1.Length-1;
            //while (mask <=8)
            //{   if (result1[i] != 0)
            //    result += (byte)Math.Pow((double)2, (double)(result1.Length - i - 1));
            //    mask = (byte)((int)mask << 1);
            //    Console.WriteLine(Convert.ToString(result, toBase: 2));
            //    i--;
            //}
            //Console.WriteLine(Convert.ToString(result, toBase: 2));
            //BitArray b = new BitArray(8);
            //bool[] myBools = new bool[8] { true, false, true, false, true, false, true, false };
            //b= new BitArray(myBools);


            //00100000 01011011 00001011 01111000 11010001 01110010 , 
            //11011100 01001101 01000011 01000000 11101100 00010001"

            byte[] tt = { 32, 91, 11, 120, 209, 114, 220, 77, 66, 43, 40, 236, 128,236,17, 236, 17,236,17,236,17,236  };
            byte[] tt1 = { 32, 91, 11, 78, 209, 114, 220, 77, 43, 40, 237, 17 };
            byte[] result = ReedSolomonAlgorithm.Encode(tt, 7);
            byte[] result1 = ReedSolomonAlgorithm.Decode(tt1, result);
            //result = 2,32,103,49,210,205,24
            Console.ReadLine();

        }
    }
}
